---
layout: page
title: 
permalink: /about/
---

# **¿Quien soy?**

Soy Juan Rogelio Salvatierra Mora nací el 11 de Diciembre en 1999 en la ciudad de Guayaquil-Ecuador, actualmente residente del sector la Ladrillera.




# **¿Por qué estudio Ingeniería en Software?**

Porque desde pequeño me he sentido atraído por la tecnología, software y el hardware.
Al principio mi aspiración era estudiar Ingeniería en Sistema Computacionales pero la Universidad de Guayaquil no tenía a su disposición la carreara así que me pareció interesante escoger la carrera de Ingeniería en Software.

